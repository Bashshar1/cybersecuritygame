#Name : Bashshar Bin Atif
#Date : Sept 6 2019
#Class: ICS3U1-01
# This is program which prints "Hello World"

print ("hello world")
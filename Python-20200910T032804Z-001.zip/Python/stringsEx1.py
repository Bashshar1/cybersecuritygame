name = "Bob"
bill = 45.1
print ("Hi %s, your bill comes to $%.2f" % (name, bill))
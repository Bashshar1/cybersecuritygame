#Name : Bashshar Bin Atif
#Date : Sept 17 2019
#Class: ICS3U1-01
# This is program  

pay = 10.25*29
print ("A student works for 29 hours at $10.25/hour. Their pay is $" + str(pay) + ".")
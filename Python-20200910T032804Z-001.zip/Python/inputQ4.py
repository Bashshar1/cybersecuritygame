#Name : Bashshar Bin Atif
#Date : Sept 18 2019
#Class: ICS3U1-01
# This is program calculates the distances between two coordinates
import math
cord1x = float(input ("What is the X coordinate of your first coordinate?"))
cord1y = float(input ("What is the Y coordinate of your first coordinate?"))
cord2x = float(input ("What is the X coordinate of your second coordinate?"))
cord2y = float(input ("What is the Y coordinate of your second coordinate?"))
distx = cord2x-cord1x
disty = cord2y-cord1y
tdist = round(math.sqrt(abs(distx**2 + disty**2)))
print (tdist)
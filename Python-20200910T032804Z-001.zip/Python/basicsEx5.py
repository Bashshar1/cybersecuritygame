#Name : Bashshar Bin Atif
#Date : Sept 6 2019
#Class: ICS3U1-01
# This is program which prints scores of different teams

print ("American League East ")
print ("Team       \tW\tL\tPCT\tGB")
print ("Baltimore  \t86\t59\t.593\t-")
print ("Toronto    \t75\t69\t.521\t10.5")
print ("NY Yankees \t73\t69\t.514\t11.5")
print ("Tampa Bay  \t70\t75\t.483\t16")
print ("Boston     \t63\t83\t.432\t23.5")
# \t (Make sure You use back slash! It makes a tab...
 
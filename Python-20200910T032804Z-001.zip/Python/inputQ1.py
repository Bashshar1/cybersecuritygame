#Name : Bashshar Bin Atif
#Date : Sept 17 2019
#Class: ICS3U1-01
# This is program calculates the circumference and area of a circle.
import math 
radius = float(input(" What is the radius of the circle you would like the area and circumference of?")) #Getting input
circum = 2*math.pi*radius                                                                                #Calculations
area = math.pi*(radius)**2
print ("A circle with the radius", radius,"cm has a circumference of", str(circum), "cm and an area of", area,  "square centimeters.") #Final Statement.
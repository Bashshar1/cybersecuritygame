#Name : Bashshar Bin Atif
#Date : Sept 18 2019
#Class: ICS3U1-01
# This is program converts CAD in to EUR
cad = float(input("How much money would you like to calculate?"))
eur = cad*0.68
print (cad, "Canadian Dollars is worth", eur, ("Euros"))

celsius = 20
fahren = celsius*9/5+3
print("20 degrees celsius is", str(fahren)+ " degrees fahrenheit." )
 
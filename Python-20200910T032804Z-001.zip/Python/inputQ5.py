#Name : Bashshar Bin Atif
#Date : Sept 18 2019
#Class: ICS3U1-01
# This is program calculates the amount of pizza each person at the party gets. 

guests = float(input("Hey Jenny! How many people are coming?"))

#equations
opt1  = 32//guests
opt1r = 32%guests
opt2 = 32/guests

#print commandsSSSSS
print ("Number of Guests :", guests)
print ("Option 1:", opt1, "slices each", opt1r, "left over")
print ("Option 2:", opt2, "slices each")
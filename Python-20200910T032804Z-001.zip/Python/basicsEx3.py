#Name : Bashshar Bin Atif
#Date : Sept 6 2019
#Class: ICS3U1-01
# This is program which prints my adress, school and name in the center.

print ("                                   Bashshar")
print ("                                  56 Orsett")
print ("                                     WOSS") 
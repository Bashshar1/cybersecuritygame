#Name: Bashshar Bin Atif
#Date: 9/23/2019
# This program prints four numbers' sum with a format (recipt).
cost1 = 12.89
cost2 = 18.99
cost3 = 20.00
no_tax_total = cost1+cost2+cost3
HST   = 0.13*no_tax_total
total = 1.13*no_tax_total
print ("Woss Gift Shop Recipt") 
print ("---------------------")
print ("glove            $%5.2f"%(cost1))
print ("toque            $%5.2f"%(cost2))
print ("scarf            $%5.2f"%(cost3))
print ("                 -------")
print ("HST              $%5.2f"%(HST))
print ("                 -------")
print ("TOTAL            $%5.2f"%(total))
#Name : Bashshar Bin Atif
#Date : Sept 6 2019
#Class: ICS3U1-01
# This is program which prints "Bonjour"

Print ("Bonjour") #this is a syntax error 
# A syntax error is an error which has the wrong of the program so the computer does not understand and excute the code
# A runtime error is an error which does not exist until you run the actual program
# A semantic error runs perfectly but does not excectute the task as intended by the programmer. 

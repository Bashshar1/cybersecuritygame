#Name : Bashshar Bin Atif
#Date : Sept 6 2019
#Class: ICS3U1-01
# This program prints a picture

print ("                                                    + ")
print ("                                                   /*\ ")
print ("                                                   |||    ")
print ("                 *                                 |||    ")
print ("                **                                 |||    ")
print ("         ____  *                                   |||    ")
print ("        /    \||                                   |||    ")
print ("       /      \|                                  /|||\ ")
print ("      /        \                                 /  *  \   ")
print ("     /|========|\                                  ***    ")
print ("      | + || + |                                    *   ")
print (" _____|_+_||_+_|______________________________/===========\________")
#Name : Bashshar Bin Atif
#Date : Sept 13 2019
#Class: ICS3U1-01
# This is program  

carspeed = 300*4.5
print ("A car travelling 300km for 4.5 hours has an average velocity of", str( carspeed ) +"km/h")
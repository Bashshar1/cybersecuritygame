#Name : Bashshar Bin Atif
#Date : Sept 13 2019
#Class: ICS3U1-01
# This is program converts celcius to fahreinet. 

celsius = 20
fahren = int(celsius *9/5 +32)
print ("20 degrees celsius is %.2f degrees fahrenheit" %fahren)

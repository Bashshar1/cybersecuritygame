#Name: Bashshar Bin Atif
#Date: 9/23/2019
# This program prints four numbers' sum.
price1 = 2.55
price2 = 3.20 
price3 = 4.00
total = price1+price2+price3
print ("$%.2f + $%.2f + $%.2f = $%.2f" % (price1,price2,price3,total))
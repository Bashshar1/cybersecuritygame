#Name : Bashshar Bin Atif
#Date : Sept 6 2019
#Class: ICS3U1-01
# This is program which prints my name, school and address in the center.

print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
print("X                                                      X")
print("X                                                      X")
print("X                                                      X")
print("X                                                      X")
print("X                       Bashshar                       X")
print("X                       56 Orsett                      X")
print("X                         WOSS                         X")
print("X                                                      X")
print("X                                                      X")
print("X                                                      X")
print("X                                                      X")
print("X                                                      X")
print("X                                                      X")
print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
#Name : Bashshar Bin Atif
#Date : Sept 13 2019
#Class: ICS3U1-01
# This prohram calculates a circumference of a circle.
import math 
circum = round (math.pi*3*2, 2)
area = round (math.pi*3**2, 2)
print("A circle with radius of 3 cm has an area of", area, "sqaure centimeters and a curcumference of", circum, "cm")
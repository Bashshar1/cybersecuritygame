carspeed = (2.5)*(80.5)
print ("A car travelling at 80.5km/h for 2.5 hours would travel", carspeed,"km")
       
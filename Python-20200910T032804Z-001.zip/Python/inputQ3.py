#Name : Bashshar Bin Atif
#Date : Sept 18 2019
#Class: ICS3U1-01
# This is program reverses a user's first and last names and puts a comma between them
first = input ("What is your first name?")
last = input ("What is your last name?")
print (last,"," ,first)
#Name: Bashshar Bin Atif
#Date: 9/23/2019
# This program prints four numbers' sum with a format.
price1 = 2.55
price2 = 3.20 
price3 = 4.00
total = price1+price2+price3
print ("Item one:     $%-5.2f" %(price1)) 
print ("Item two:     $%-5.2f"% (price2))
print ("Item three:   $%-5.2f"%(price3))
print ("              ------")
print      ("Total cost: $%-5.2f" %(total))
#IS THIS CORRECT?!